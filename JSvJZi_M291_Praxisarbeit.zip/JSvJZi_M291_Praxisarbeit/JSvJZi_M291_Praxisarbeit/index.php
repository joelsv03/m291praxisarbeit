<!DOCTYPE html>
<html lang="de">	
<?php
require_once 'connect.php';

?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DB App</title>
</head>
<body>
	
	
    <table style="background-color:smokewhite; width: 100wv;">
    <tr><th>ID</th><th>Name</th><th>Email</th><th colspan="2">Edit</th></tr>
<?php 
	$query = "SELECT * FROM Entry"; 
	if($resultset = $db-> query($query)){
		foreach( $resultset as $row){
			echo " 
				<tr> 
				<td><a href='".$row["entry_link"]."'>".$row["link_name"]."</td>
				<td>".$row["name"]." </td>
				<td>".$row["email"]." </td>
				<td>
					<form method ='post' action='delete.php'>
						<input type='hidden' name='Entry_id' value=".$row["id"].">
						<input type='submit' value='delete'>
					</form>
				</tr>";
		}
	}
$db -> close();
?>
	
		
<form method="post" action="insert.php">
	
	<label for="link_name">Name</label>
    <input type="text" name="link_name" id="link_name"><br>
	
    <label for="entry_link">Email</label>
    <input type="text" name="entry_link" id="entry_link"><br>

    <input type="submit" value="OK">
</form>

</body>
</html>