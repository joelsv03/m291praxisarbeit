<?php
/** @var mysqli $db */

$db = mysqli_connect ('localhost:3306','m291praxisarbeit','yM4e6f#3','m291praxisarbeit') or die('datenbank verbindung nicht möglich');
?>