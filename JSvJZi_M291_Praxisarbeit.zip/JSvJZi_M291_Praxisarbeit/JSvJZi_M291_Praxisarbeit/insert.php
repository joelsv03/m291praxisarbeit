<?php
$link_name = $_POST['link_name'];
$entry_link = $_POST['entry_link'];
$sprache = $_POST['sprache'];
$kategorie = $_POST['kategorie'];

require_once 'connect.php';

$sql ="INSERT INTO Entry (kategorie,sprache,entry_link,link_name) VALUES (?,?,?,?)";

if($stmt = $db-> prepare ($sql)){

	$stmt -> bind_param("ssss", $kategorie,$sprache,$entry_link,$link_name);
	$stmt -> execute();
	
		
	echo "Neuer Datensatz hinzugefügt: " . $db-> affected_rows;
	
}
else{

	echo "Es funktioniert nicht";
}

$db-> query($sql);
$stmt -> close();
$db-> close();
?>
<p><a href="./">Zurück</a></p>

